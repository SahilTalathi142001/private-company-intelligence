from __future__ import annotations

import hashlib
import json
import re
from datetime import datetime, timezone
from pathlib import Path

import pandas as pd

import json

REPO_ROOT = Path(__file__).resolve().parents[3]

SILVER_ROOT = REPO_ROOT / "data" / "silver" / "documents"

SUPPORTED_DOCUMENT_CLASSES = {
    "SEC_10_K",
    "SEC_10_Q",
    "SEC_8_K",
    "SEC_FORM_D",
    "SEC_OTHER",
    "TEXT_DOCUMENT",
    "HTML_DOCUMENT",
    "PDF_DOCUMENT",
    "OTHER",
}

UNDERSTANDING_STATUSES = {
    "SUCCESS",
    "NO_SUPPORTED_FACTS",
    "FAILED",
}


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _normalise(value) -> str:
    if value is None:
        return ""

    if pd.isna(value):
        return ""

    return str(value).strip()


def _safe_float(value):
    value = _normalise(value)

    if not value:
        return None

    value = value.replace(",", "")
    value = value.replace("$", "")

    try:
        return float(value)
    except ValueError:
        return None


def _load_parquet(path: Path) -> pd.DataFrame:
    if not path.is_file():
        raise FileNotFoundError(path)

    frame = pd.read_parquet(path)

    if frame.empty:
        raise ValueError(f"Empty parquet artifact: {path}")

    return frame


def _load_classification(
    document_dir: Path,
) -> pd.DataFrame:
    return _load_parquet(
        document_dir / "document_classification.parquet"
    )


def _load_metadata(
    document_dir: Path,
) -> pd.DataFrame:
    return _load_parquet(
        document_dir / "document_metadata.parquet"
    )


def _load_text(
    document_dir: Path,
) -> pd.DataFrame:
    return _load_parquet(
        document_dir / "document_text.parquet"
    )


def _first_value(frame: pd.DataFrame, column: str) -> str:
    if column not in frame.columns or frame.empty:
        return ""

    return _normalise(frame.iloc[0][column])


def _document_text(frame: pd.DataFrame) -> str:
    if frame.empty:
        return ""

    text_columns = [
        "text",
        "page_text",
        "content",
        "document_text",
    ]

    for column in text_columns:
        if column in frame.columns:
            values = [
                _normalise(value)
                for value in frame[column].tolist()
            ]

            values = [value for value in values if value]

            if values:
                return "\n".join(values)

    return ""


def _search(
    text: str,
    pattern: str,
    flags=re.IGNORECASE,
):
    match = re.search(pattern, text, flags)

    if not match:
        return None

    return match


def _extract_filing_date(text: str) -> str | None:
    patterns = [
        r"\b(?:filing|filed)\s+date\s*[:\-]?\s*(\d{4}-\d{2}-\d{2}|\d{1,2}/\d{1,2}/\d{4})\b",
        r"\bfiled\s+on\s*[:\-]?\s*(\d{4}-\d{2}-\d{2}|\d{1,2}/\d{1,2}/\d{4})\b",
        r"\bfiled\s*[:\-]?\s*(\d{4}-\d{2}-\d{2}|\d{1,2}/\d{1,2}/\d{4})\b",
    ]

    for pattern in patterns:
        match = _search(text, pattern)

        if match:
            return match.group(1)

    return None


def _extract_form_d_facts(text: str) -> dict:
    facts = {}

    filing_date = _extract_filing_date(text)

    if filing_date:
        facts["filing_date"] = filing_date

    issuer_patterns = [
        r"ISSUER(?:\s+NAME)?\s*[:\-]\s*([^\n\r]+)",
        r"NAME OF ISSUER\s*[:\-]\s*([^\n\r]+)",
    ]

    for pattern in issuer_patterns:
        match = _search(text, pattern)

        if match:
            facts["issuer_name"] = match.group(1).strip()
            break

    offering_patterns = [
        r"TOTAL OFFERING AMOUNT\s*[:\-]?\s*\$?\s*([\d,]+(?:\.\d+)?)",
        r"TOTAL OFFERING\s*[:\-]?\s*\$?\s*([\d,]+(?:\.\d+)?)",
    ]

    for pattern in offering_patterns:
        match = _search(text, pattern)

        if match:
            facts["total_offering_amount"] = _safe_float(
                match.group(1)
            )
            break

    sold_patterns = [
        r"TOTAL AMOUNT SOLD\s*[:\-]?\s*\$?\s*([\d,]+(?:\.\d+)?)",
        r"AMOUNT SOLD\s*[:\-]?\s*\$?\s*([\d,]+(?:\.\d+)?)",
    ]

    for pattern in sold_patterns:
        match = _search(text, pattern)

        if match:
            facts["total_amount_sold"] = _safe_float(
                match.group(1)
            )
            break

    return facts


def _extract_sec_facts(
    document_class: str,
    text: str,
) -> tuple[dict, list[dict]]:

    facts = {}
    events = []

    filing_date = _extract_filing_date(text)

    if filing_date:
        facts["filing_date"] = filing_date

    if document_class == "SEC_FORM_D":
        form_d_facts = _extract_form_d_facts(text)
        facts.update(form_d_facts)

        events.append(
            {
                "event_type": "SEC_FORM_D_FILING",
                "event_status": "CONFIRMED",
                "event_confidence": 1.0,
                "event_method": "DETERMINISTIC_RULE",
            }
        )

    elif document_class in {
        "SEC_10_K",
        "SEC_10_Q",
        "SEC_8_K",
        "SEC_OTHER",
    }:
        events.append(
            {
                "event_type": "SEC_FILING",
                "event_status": "CONFIRMED",
                "event_confidence": 1.0,
                "event_method": "DOCUMENT_CLASS",
            }
        )

    return facts, events


def _build_event_rows(
    *,
    document_id: str,
    company_id: str,
    cik: str,
    document_class: str,
    source_filename: str,
    source_path: str,
    sha256: str,
    facts: dict,
    events: list[dict],
) -> list[dict]:

    rows = []
    serialised_facts = facts.copy()

    for amount_field in (
        "total_offering_amount",
        "total_amount_sold",
    ):
        amount = serialised_facts.get(amount_field)

        if isinstance(amount, (int, float)):
            serialised_facts[amount_field] = format(amount, ",")

    for event in events:
        rows.append(
            {
                "document_id": document_id,
                "company_id": company_id,
                "cik": cik,
                "document_class": document_class,
                "event_type": event["event_type"],
                "event_status": event["event_status"],
                "event_confidence": event["event_confidence"],
                "event_method": event["event_method"],
                "source_filename": source_filename,
                "source_path": source_path,
                "sha256": sha256,
                "facts_json": json.dumps(
                    serialised_facts,
                    ensure_ascii=False,
                    sort_keys=True,
                ),
                "created_at_utc": _utc_now(),
            }
        )

    return rows


def _already_understood(
    path: Path,
    sha256: str,
) -> bool:

    if not path.is_file():
        return False

    try:
        frame = pd.read_parquet(path)
    except Exception:
        return False

    if frame.empty:
        return False

    if "sha256" not in frame.columns:
        return False

    if "understanding_status" not in frame.columns:
        return False

    matching_rows = (
        (
            frame["sha256"].astype(str) == sha256
        )
        & (
            frame["understanding_status"].astype(str)
            == "SUCCESS"
        )
    )
    return bool(matching_rows.any())


def _write_atomic(
    frame: pd.DataFrame,
    path: Path,
) -> None:

    path.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    tmp = path.with_suffix(".tmp.parquet")

    frame.to_parquet(
        tmp,
        index=False,
    )

    tmp.replace(path)


def understand_documents_for_company(
    cik: str,
    *,
    force: bool = False,
    document_id: str | None = None,
) -> dict:

    cik = str(cik).zfill(10)

    company_root = (
        SILVER_ROOT / f"cik={cik}"
    )

    if not company_root.is_dir():
        return {
            "discovered": 0,
            "understood": 0,
            "skipped": 0,
            "failed": 0,
            "results": [],
        }

    results = []

    document_dirs = [
        path
        for path in company_root.iterdir()
        if path.is_dir()
    ]

    discovered = len(document_dirs)
    understood = 0
    skipped = 0
    failed = 0

    for document_dir in document_dirs:

        current_document_id = document_dir.name
        if document_id and current_document_id != str(document_id).strip():
            continue

        try:
            metadata = _load_metadata(
                document_dir
            )

            classification = _load_classification(
                document_dir
            )

            text_frame = _load_text(
                document_dir
            )

            company_id = _first_value(
                metadata,
                "company_id",
            )

            source_path = _first_value(
                metadata,
                "source_path",
            )

            source_filename = _first_value(
                metadata,
                "source_filename",
            )

            sha256 = _first_value(
                metadata,
                "sha256",
            )

            document_class = _first_value(
                classification,
                "document_class",
            )

            if document_class not in SUPPORTED_DOCUMENT_CLASSES:
                raise ValueError(
                    f"Unsupported document class: "
                    f"{document_class}"
                )

            text = _document_text(text_frame)

            if not text:
                raise ValueError(
                    f"No extracted text for "
                    f"document {current_document_id}"
                )

            output_path = (
                document_dir
                / "document_understanding.parquet"
            )

            if not force and _already_understood(
                output_path,
                sha256,
            ):
                skipped += 1

                existing = pd.read_parquet(output_path)
                events = []
                facts = {}

                for _, row in existing.iterrows():
                    row_facts = json.loads(
                        _normalise(row.get("facts_json")) or "{}"
                    )
                    if not facts:
                        facts = row_facts

                    event_type = _normalise(row.get("event_type"))
                    if event_type:
                        events.append(
                            {
                                "event_type": event_type,
                                "event_status": _normalise(
                                    row.get("event_status")
                                ),
                                "event_confidence": float(
                                    row.get("event_confidence") or 0.0
                                ),
                                "event_method": _normalise(
                                    row.get("event_method")
                                ),
                            }
                        )

                results.append(
                    {
                        "document_id": current_document_id,
                        "document_class": document_class,
                        "source_path": source_path,
                        "sha256": sha256,
                        "status": "SKIPPED",
                        "facts": facts,
                        "events": events,
                    }
                )

                continue

            facts = {}
            events = []

            if document_class.startswith("SEC_"):
                facts, events = _extract_sec_facts(
                    document_class,
                    text,
                )

            understanding_status = (
                "SUCCESS"
                if facts or events
                else "NO_SUPPORTED_FACTS"
            )

            event_rows = _build_event_rows(
                document_id=document_id,
                company_id=company_id,
                cik=cik,
                document_class=document_class,
                source_filename=source_filename,
                source_path=source_path,
                sha256=sha256,
                facts=facts,
                events=events,
            )

            output_rows = []

            if event_rows:
                for event_row in event_rows:
                    output_rows.append(
                        {
                            **event_row,
                            "understanding_status":
                                understanding_status,
                        }
                    )
            else:
                output_rows.append(
                    {
                        "document_id": current_document_id,
                        "company_id": company_id,
                        "cik": cik,
                        "document_class": document_class,
                        "event_type": None,
                        "event_status": None,
                        "event_confidence": None,
                        "event_method": None,
                        "source_filename": source_filename,
                        "source_path": source_path,
                        "sha256": sha256,
                        "facts_json": json.dumps(facts, sort_keys=True),
                        "understanding_status":
                            understanding_status,
                        "created_at_utc": _utc_now(),
                    }
                )

            _write_atomic(
                pd.DataFrame(output_rows),
                output_path,
            )

            understood += 1

            results.append(
                {
                    "document_id": current_document_id,
                    "document_class": document_class,
                    "source_path": source_path,
                    "sha256": sha256,
                    "status": understanding_status,
                    "facts": facts,
                    "events": events,
                }
            )

        except Exception as exc:

            failed += 1

            results.append(
                {
                    "document_id": current_document_id,
                    "status": "FAILED",
                    "error": str(exc),
                }
            )

    return {
        "discovered": discovered,
        "understood": understood,
        "skipped": skipped,
        "failed": failed,
        "results": results,
    }