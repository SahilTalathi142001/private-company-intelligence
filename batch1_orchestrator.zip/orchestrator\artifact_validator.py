"""Validate persisted outputs before an incremental component is allowed to run.

The paths below are taken from integration_v2/components.py. Company-scoped
outputs are checked directly; shared outputs are checked for a row belonging
to the requested CIK.
"""
from __future__ import annotations

from pathlib import Path
from typing import Callable
import pandas as pd

ROOT = Path(__file__).resolve().parents[3]


def _path(*parts: str) -> Path:
    return ROOT.joinpath(*parts)


def _cik_from_company_id(company_id: str) -> str:
    # ExecutionContext.new() stores companies as SEC_<10-digit CIK>.
    return str(company_id).replace("SEC_", "").zfill(10)


def _company_file(component_id: str, cik: str) -> list[Path]:
    """Return persisted output paths for company-scoped components."""
    paths = {
        "sec_ingestion": [
            _path("data", "bronze", "sec", "submissions", f"{cik}.json"),
            _path("data", "bronze", "sec", "companyfacts", f"{cik}.json"),
        ],
        "financial_normalization": [
            _path("data", "silver", "financial_facts", f"cik={cik}", "financial_facts.parquet"),
            _path("data", "gold", "financials", f"cik={cik}", "financials.parquet"),
        ],
        "quarter_derivation": [
            _path("data", "gold", "financials_quarterly", f"cik={cik}", "financials_quarterly.parquet"),
            _path("data", "gold", "financials_quarterly_final", f"cik={cik}", "financials_quarterly.parquet"),
            _path("data", "gold", "financials_analytics", f"cik={cik}", "financials_analytics.parquet"),
        ],
        "financial_features": [
            _path("data", "gold", "financials_features", f"cik={cik}", "financial_features.parquet"),
        ],
    }
    return paths.get(component_id, [])


# These components write shared tables according to components.py. Their
# company membership must be verified by reading the CIK column.
_SHARED = {
    "financial_decision": [
        _path("data", "gold", "financial_decision_intelligence", "decision_signals", "financial_decision_signals.parquet"),
        _path("data", "gold", "financial_decision_intelligence", "company_financial_decision_snapshot", "company_financial_decision_snapshot.parquet"),
        _path("data", "gold", "financial_decision_intelligence", "financial_decision_summary", "financial_decision_summary.parquet"),
    ],
    "company_profile": [
        _path("data", "gold", "financial_company_intelligence", "company_intelligence_profile", "company_intelligence_profile.parquet"),
        _path("data", "gold", "financial_company_intelligence", "company_intelligence_history", "company_intelligence_history.parquet"),
        _path("data", "gold", "financial_company_intelligence", "company_intelligence_signals", "company_intelligence_signals.parquet"),
        _path("data", "gold", "financial_company_intelligence", "company_intelligence_summary", "company_intelligence_summary.parquet"),
        _path("data", "gold", "financial_company_intelligence", "company_intelligence_lineage", "company_intelligence_lineage.parquet"),
        _path("data", "gold", "financial_company_intelligence_dq", "profile_quality_audit", "profile_quality_audit.parquet"),
        _path("data", "gold", "financial_company_intelligence_dq", "profile_dq_summary", "profile_dq_summary.parquet"),
    ],
    "form_d_ingestion": [
        _path("data", "gold", "funding_capital_intelligence", "funding_events", "funding_events.parquet"),
        _path("data", "gold", "funding_capital_intelligence", "company_funding_snapshot", "company_funding_snapshot.parquet"),
    ],
    "investor_ownership": [
        _path("data", "gold", "investor_ownership_intelligence", "ownership_snapshot", "ownership_snapshot.parquet"),
    ],
    "valuation": [
        _path("data", "gold", "valuation_intelligence", "company_valuation_snapshot", "company_valuation_snapshot.parquet"),
    ],
    "investment_intelligence": [
        _path("data", "gold", "unified_investment_intelligence", "investment_profile", "investment_profile.parquet"),
        _path("data", "gold", "unified_investment_intelligence", "investment_signals", "investment_signals.parquet"),
        _path("data", "gold", "unified_investment_intelligence", "investment_summary", "investment_summary.parquet"),
    ],
}
_GLOBAL_METADATA = {
    "financial_decision": {
        "financial_decision_summary.parquet",
    },
    "company_profile": {
        "company_intelligence_summary.parquet",
        "company_intelligence_lineage.parquet",
        "profile_dq_summary.parquet",
    },
}


def _validate_parquet(
    path: Path,
    cik: str,
    require_identity: bool = True,
) -> tuple[bool, str]:
    if not path.is_file():
        return False, f"MISSING:{path}"

    try:
        frame = pd.read_parquet(path)
    except Exception as exc:
        return False, f"UNREADABLE:{path}:{type(exc).__name__}"

    if frame.empty:
        return False, f"EMPTY:{path}"

    if "cik" in frame.columns:
        matches = (
            frame["cik"].astype(str)
            .str.replace(r"\.0$", "", regex=True)
            .str.zfill(10) == cik
        )
        if not matches.any():
            return False, f"COMPANY_NOT_PRESENT:{path}:CIK={cik}"
    elif require_identity and "cik=" not in str(path):
        return False, f"IDENTITY_UNVERIFIABLE:{path}:NO_CIK_COLUMN"

    return True, "OK"


def validate_artifact(
    company_id: str,
    component_id: str,
    pipeline_version: str,
) -> tuple[bool, str]:
    """Return (valid, reason) for a prerequisite's persisted output.

    `pipeline_version` is accepted to match the orchestrator callback contract.
    Current component outputs do not persist a version manifest, so version
    compatibility cannot yet be asserted here.
    """
    cik = _cik_from_company_id(company_id)
    scoped = _company_file(component_id, cik)
    shared = _SHARED.get(component_id)

    if scoped:
        checks = [_validate_json(p) if p.suffix == ".json" else _validate_parquet(p, cik)
                  for p in scoped]
    elif shared:
         global_metadata = _GLOBAL_METADATA.get(component_id, set())
         checks = [
        _validate_parquet(
            path,
            cik,
            require_identity=path.name not in global_metadata,
        )
        for path in shared
    ]
    else:
        return False, f"NO_ARTIFACT_CONTRACT:{component_id}"

    failures = [reason for valid, reason in checks if not valid]
    if failures:
        return False, ";".join(failures)
    return True, "OK"


def _validate_json(path: Path) -> tuple[bool, str]:
    import json
    if not path.is_file():
        return False, f"MISSING:{path}"
    try:
        with path.open("r", encoding="utf-8") as handle:
            payload = json.load(handle)
    except Exception as exc:
        return False, f"UNREADABLE:{path}:{type(exc).__name__}"
    if not payload:
        return False, f"EMPTY:{path}"
    return True, "OK"
